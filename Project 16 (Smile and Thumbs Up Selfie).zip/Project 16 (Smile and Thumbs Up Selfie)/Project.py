import cv2
import os
import HandTrackingModule as htm
import numpy as np
import time

# Variables
width, height = 640, 480
gestureThreshhold = 200
buttonPressed = False

#Cascade
faceCascade = cv2.CascadeClassifier("xml/haarcascade_frontalface_default.xml")
smileCascade = cv2.CascadeClassifier("xml/haarcascade_smile_default.xml")

# Camera Setup
cap = cv2.VideoCapture(0)
cap.set(3,width)
cap.set(4,height)

# Hand Detector
detector = htm.HandDetector(detectionCon=0.8, maxHands=4)

while True:

    success, img = cap.read()
    img = cv2.flip(img, 1)

    gray = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    face = faceCascade.detectMultiScale(gray, scaleFactor=1.1, minNeighbors=10)

    hands, img = detector.findHands(img)
    #cv2.line(img, (0, gestureThreshhold), (width, gestureThreshhold), (250, 0, 0), 1)
    cv2.line(img, (0, 240), (70, 240), (250, 0, 0), 5)
    cv2.line(img, (570, 240), (640, 240), (250, 0, 0), 5)

    for x,y,w,h in face:
        cv2.rectangle(img,(x,y),(x+w,y+h),(0,0,255),1)
        smile=smileCascade.detectMultiScale(gray,scaleFactor=1.8,minNeighbors=20)
        for x,y,w,h in smile:
            cv2.rectangle(img,(x,y),(x+w,y+h),(0,255,0),1)

    # If hands are present then
    if hands and buttonPressed is False:
        hand = hands[0]
        fingers = detector.fingersUp(hand)
        #print(fingers)
        cx, cy = hand['center']
        lmList = hand['lmList']

        # If hand is at the height of face then apply gestures
        if cy <= gestureThreshhold:

            # Gesture 1 - Thumb Up
            if fingers == [1, 0, 0, 0, 0] and smileCascade:
                print("Left")
                buttonPressed = True

                cv2.imwrite(filename='saved_img.jpg', img=img)
                cap.release()
                img_new = cv2.imread('saved_img.jpg', cv2.IMREAD_GRAYSCALE)
                img_new = cv2.imshow("Captured Image", img_new)
                cv2.waitKey(1650)
                cv2.destroyAllWindows()
                print("Processing image...")
                img_ = cv2.imread('saved_img.jpg', cv2.IMREAD_ANYCOLOR)
                print("Converting RGB image to grayscale...")
                gray = cv2.cvtColor(img_, cv2.COLOR_BGR2GRAY)
                print("Resizing image to RGB scale...")
                img_ = cv2.resize(gray, (400, 400))
                print("Resized...")
                img_resized = cv2.imwrite(filename='saved_img-final.jpg', img=img_)
                print("Image saved!")
                break


    cv2.imshow("Smile", img)
    key = cv2.waitKey(1)
    if key == ord('q'):
        print("Turning off camera.")
        cap.release()
        print("Camera off.")
        print("Program ended.")
        cv2.destroyAllWindows()
        break